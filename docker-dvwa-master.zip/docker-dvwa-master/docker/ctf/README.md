# CTF Challenges

The [setup](setup) file in this directory contains obfuscated shell code to setup the CTF challenges inside the Docker image.

You can verify that by looking at the [Dockerfile](../Dockerfile) and the file itself is not doing any harm, nor will it be run on your local machine.

**I do recommend not to de-obfuscate it, as you will then have the answers for the challenges.**
